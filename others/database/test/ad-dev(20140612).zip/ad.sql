-- MySQL dump 10.13  Distrib 5.5.15, for Win32 (x86)
--
-- Host: localhost    Database: andaily_developer
-- ------------------------------------------------------
-- Server version	5.5.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backlog`
--

DROP TABLE IF EXISTS `backlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `content` text,
  `priority` varchar(255) DEFAULT 'DEFAULT',
  `type_` varchar(255) DEFAULT 'NEEDS',
  `sprint_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `join_sprint_user_id` int(11) DEFAULT NULL,
  `join_sprint_time` datetime DEFAULT NULL,
  `estimate_time` int(11) DEFAULT '0',
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `sprint_id_index` (`sprint_id`),
  KEY `join_sprint_user_id_index` (`join_sprint_user_id`),
  KEY `guid_index` (`guid`),
  KEY `creator_id_index` (`creator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backlog`
--

LOCK TABLES `backlog` WRITE;
/*!40000 ALTER TABLE `backlog` DISABLE KEYS */;
INSERT INTO `backlog` VALUES (1,'b6e6c2e021a04f9b9494f510ddcc406c','2013-09-08 11:35:33',0,'需要添加用户的引用到当前的操作, 当创建task, sprint, backlog等.','DEFAULT','NEEDS',7,61,NULL,NULL,7,5),(2,'5f8a47641a5444afbb7f08ad740929d3','2013-09-08 11:37:33',0,'asfdsffsdfewewsd','DEFAULT','NEEDS',7,61,NULL,NULL,3,5),(3,'748af5cde3ca485d80422a7886d6a858','2013-09-09 23:41:59',0,'当用户添加一个销售人员时,系统要检查销售人员的资格是否合适,是否俱有售卖资格,并需要上传个人下面的图片作为参考.等等.<br />\r\n需要要剪切功能哦.','DEFAULT','NEEDS',7,61,NULL,NULL,4,5),(4,'a3e4938a2e0449c98ddfbe2bbcb5ef47','2013-09-10 21:26:09',1,'asfwfeefsd','DEFAULT','NEEDS',NULL,61,NULL,NULL,0,5),(5,'154a3fb580964fc6b2e0916cb3cdaf8f','2013-09-10 22:40:26',0,'High ...... bugs','HIGH','BUGS',7,61,NULL,NULL,1,5),(6,'9eb32ed0e4b8454ba1ee69845ad1f5fd','2013-09-11 22:58:51',0,'asfdfsfasfaaewfwe','DEFAULT','NEEDS',7,61,NULL,NULL,3,5),(7,'0f95f4e04db441dc9346a6e48389cbd5','2013-11-06 22:50:20',0,'New backlog','DEFAULT','NEEDS',14,61,61,'2014-06-06 17:36:52',2,1),(8,'421acc88aea942e6b0063236ae7c2275','2013-11-16 11:50:36',0,'When super man(initial user,only one) login system, a developer managment menu will be show on the dashboard; another menus include system log; report<br />\r\n<br />\r\nSuper man manage project too(a menu call Project) <strong>???</strong><br />\r\nor allow Scrum master create project..<br />\r\n<br />\r\nHe can add/edit/archive/reset password of developer.&nbsp;<br />\r\n<br />\r\nDefine a domain call Team(super man manage it), a team include Product owner(one or more); Scrum master(one or more) ; Scrum memeber(one or more); team name<br />\r\n<br />\r\nA team have one or more projects.<br />\r\n<br />\r\n--------------------------------------------------------------------<br />\r\n<br />\r\nSuper man have 4 menus: Developer; Team; Monitor and Report<br />\r\n<br />\r\nOne team have one or more developer(include 3 roles developer: Scrum master, scrum member and product owner)<br />\r\n<br />\r\n&nbsp;','DEFAULT','NEEDS',NULL,61,NULL,NULL,10,5),(9,'f64fc79406f94b3eadca7f1b32326950','2013-11-16 12:10:00',1,'fasdfdssdfsd','DEFAULT','NEEDS',NULL,61,NULL,NULL,3,2),(10,'748740022b22473a81ea6517415ca6ac','2013-11-16 12:10:11',1,'asfsdfdsfsddfsfdsfdsfsdfdffd','DEFAULT','NEEDS',NULL,61,NULL,NULL,1,2),(11,'68a9babf5c7b4837a5f8c4ca80354507','2013-11-16 12:10:20',1,'sffsdssfd','DEFAULT','NEEDS',NULL,61,NULL,NULL,1,2),(12,'a5b4d49121f04b28a50e66656412737c','2014-05-22 11:35:42',0,'项目是由Team来完成的, 一个项目可以分配给Team(一个项目可以有多个Team), 每个Sprint需要指定完成它的Team&nbsp;','DEFAULT','NEEDS',NULL,61,NULL,NULL,2,5),(13,'730cf55b3fff4315af5fea6d8aa03d08','2014-05-22 11:50:05',0,'是否可以取消(Cancel) Sprint, 待讨论','DEFAULT','SUGGESTIONS',17,61,61,'2014-06-03 18:38:11',1,5),(14,'fb165618913f4f098c50bdf26fdd130f','2014-05-22 12:11:12',0,'创建项目时需要指定Product Owner(可以有多个)','DEFAULT','NEEDS',NULL,61,NULL,NULL,1,5),(15,'e438dba73a1b41dd9d5c7d020ab5cd4f','2014-05-22 16:29:38',0,'Pending Sprint allow change un-refered task Backlogs.','DEFAULT','NEEDS',17,61,61,'2014-06-03 18:38:11',1,5),(16,'6b581947a1724e858e9ba26366abcb9c','2014-05-26 10:43:07',0,'设置default&nbsp; sprint是针对每一个项目皆可以设置.而不是全局的','DEFAULT','NEEDS',17,61,61,'2014-06-03 18:38:11',1,5),(17,'1e76fc6b7efc4eb3b9628ca3d1001603','2014-05-26 10:53:20',0,'创建Sprint时的backlog要根据选择的项目(project)来变化, 而不是总是显示所有.','DEFAULT','NEEDS',17,61,61,'2014-06-03 18:38:11',1,5),(18,'aa0a210f4d3e46879366fc5eba8c651d','2014-05-26 11:13:44',0,'Task number should be generate by project, every project number start by 00001, replace global generate type','DEFAULT','NEEDS',17,61,61,'2014-06-03 18:38:11',1,5),(19,'39416b6c83c14ab0b8305620c981b712','2014-05-28 10:19:30',0,'Sprint Task allow add comment&nbsp;no matter what status','DEFAULT','NEEDS',17,54,61,'2014-06-03 18:38:11',1,5),(20,'bd1daa86d19f4a2aa4215ae3f864ccc4','2014-06-03 18:26:38',0,'Backlog document management, allow upload documents and download documents','DEFAULT','NEEDS',17,61,61,'2014-06-03 18:38:11',4,5),(21,'037cfd2754e3493793dcca034648aa48','2014-06-06 14:44:38',0,'Just test document,<br />\r\nBacklog document management, allow upload documents and download documents','DEFAULT','NEEDS',14,61,61,'2014-06-06 17:36:52',1,1),(22,'969845c68f904768a0b3a69639bf987b','2014-06-12 15:02:29',0,'OK, test it','DEFAULT','NEEDS',NULL,59,NULL,NULL,2,2);
/*!40000 ALTER TABLE `backlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `creator_id` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `backlog_id` int(11) DEFAULT NULL,
  `type_` varchar(255) DEFAULT 'Document',
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `creator_id_index` (`creator_id`),
  KEY `file_id_index` (`file_id`),
  KEY `backlog_id_index` (`backlog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` VALUES (2,'3e9432581983439f88bcc253891226fc','2014-06-06 14:44:38',0,NULL,2,21,'BacklogDocument'),(3,'398dfd98a45e40a8874ad902a9c294c5','2014-06-06 14:44:38',0,NULL,3,21,'BacklogDocument'),(4,'a1f9ab5e4a4b4cc5b8a4b9fc3c504485','2014-06-06 15:06:15',0,61,4,7,'BacklogDocument'),(5,'82c88436e4914ad68109ac0d4bb8640e','2014-06-06 15:06:40',0,61,5,7,'BacklogDocument'),(7,'381157b1c41a4b74a2ed73b865108deb','2014-06-06 17:03:10',0,61,7,20,'BacklogDocument'),(8,'ce582e4241af4314be54e0d50a51b5dd','2014-06-09 11:33:55',0,61,8,7,'BacklogDocument');
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gecko_file`
--

DROP TABLE IF EXISTS `gecko_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gecko_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `name_` varchar(255) DEFAULT NULL,
  `path_` varchar(255) DEFAULT NULL,
  `suffix` varchar(255) DEFAULT NULL,
  `temp_` tinyint(1) DEFAULT '0',
  `size_` int(20) DEFAULT '0',
  `type_` varchar(255) DEFAULT 'GeckoFile',
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gecko_file`
--

LOCK TABLES `gecko_file` WRITE;
/*!40000 ALTER TABLE `gecko_file` DISABLE KEYS */;
INSERT INTO `gecko_file` VALUES (2,'157c14a46e6d43359a9300798118ce61','2014-06-06 14:44:38',0,'logo-wdcy.png','82f2215b990e426793e7be5f4bc79679','png',0,16192,'GeckoFile'),(3,'274ca5c4213e4dce8a27d805b18c4b2f','2014-06-06 14:44:38',0,'wdcy.js','f6baeab392c84ea6bbb9983cb7f55612','js',0,13856,'GeckoFile'),(4,'ac6cb4e923394cbc80f76a344c2f5ec8','2014-06-06 15:06:15',0,'logo-wdcy.png','53de362d032b41b4b5b15b4e71f482e3','png',0,16192,'GeckoFile'),(5,'bb47146e53684aa790b4a345cb8108f7','2014-06-06 15:06:40',0,'wdcy.js','5d5877ddbbda4d97a2a01a9fec65b358','js',0,13856,'GeckoFile'),(7,'2a4b318f0d9c4b57b9d5c7bc3da41a3d','2014-06-06 17:03:10',0,'wdcy.js','249a9bfa20ff45289aa356063446d4ca','js',0,13856,'GeckoFile'),(8,'a6243dd3a9bf476f8bf52ba6940f7d99','2014-06-09 11:33:54',0,'文档 - WDCY Developer.htm','bf42ad7fd8634c6d85b6b05bb0db9fab','htm',0,8524,'GeckoFile');
/*!40000 ALTER TABLE `gecko_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `name_` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `description` text,
  `finish_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `creator_id_index` (`creator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (1,'0e24f4ed47714b5b85f9cf44a8d35c71','2013-10-22 22:32:27',0,'Gecko','GK',NULL,'safsdfsf',NULL),(2,'71323ef8f6724a42b40347fa1e17c4d8','2013-10-22 22:40:34',0,'Rubbit','RB',NULL,'Andaily是一个项目<br />\r\n<br />\r\n<strong>要完成日常的管理.&nbsp;</strong><br />\r\n<br />\r\n&nbsp;','2013-12-31'),(3,'eee052533c3940369573656f53ca594d','2013-10-29 22:47:34',1,'asffsfdsdf','',NULL,'sfsfds','2013-10-30'),(4,'f5efa38e6a7844d49321dc40cb035967','2013-10-29 22:48:16',1,'ate','',NULL,'afdsdsf','2013-10-30'),(5,'b7da5d807c8c443fa73d19c43ccf6718','2013-10-29 23:08:00',0,'Andaily-developer','AD',NULL,'Andaily-developer , from Andaily .','2013-12-31'),(6,'17ce596a278d43f7adc816c99222adb9','2014-05-21 17:26:12',0,'ZSFZ','zsfz',NULL,'zsfz football club','2014-11-30'),(7,'a7f12c93a5a842f58e47c4870dfcc4da','2014-05-26 14:28:47',0,'WDCY','wdcy',50,'WDCY project',NULL);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_developer`
--

DROP TABLE IF EXISTS `project_developer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_developer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `project_id` int(11) DEFAULT NULL,
  `developer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `developer_id_index` (`developer_id`),
  KEY `project_id_index` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_developer`
--

LOCK TABLES `project_developer` WRITE;
/*!40000 ALTER TABLE `project_developer` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_developer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_product_owner`
--

DROP TABLE IF EXISTS `project_product_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_product_owner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `project_id` int(11) DEFAULT NULL,
  `product_owner_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `product_owner_id_index` (`product_owner_id`),
  KEY `project_id_index` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_product_owner`
--

LOCK TABLES `project_product_owner` WRITE;
/*!40000 ALTER TABLE `project_product_owner` DISABLE KEYS */;
INSERT INTO `project_product_owner` VALUES (21,'b4f768f24e2d42d6b6af44366357d333','2014-05-26 14:28:47',0,7,54),(22,'72a5407dc6b7452c9761c1b05b8ca208','2014-05-26 14:29:46',0,6,54),(23,'72cea0967d9341d999b3d87171dbc34f','2014-05-26 14:29:46',0,6,62),(24,'d7d6a978622640b5bdd5869a7f965f0a','2014-05-26 17:09:14',0,5,54);
/*!40000 ALTER TABLE `project_product_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scrum_comment`
--

DROP TABLE IF EXISTS `scrum_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scrum_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `developer_id` int(11) DEFAULT NULL,
  `comment_time` datetime DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `developer_id_index` (`developer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scrum_comment`
--

LOCK TABLES `scrum_comment` WRITE;
/*!40000 ALTER TABLE `scrum_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `scrum_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sprint`
--

DROP TABLE IF EXISTS `sprint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sprint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `creator_id` int(11) DEFAULT NULL,
  `name_` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `status` varchar(255) DEFAULT 'CREATED',
  `pending_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `archive_time` datetime DEFAULT NULL,
  `archive_user_id` int(11) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `default_sprint` tinyint(1) DEFAULT '0',
  `execute_team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `creator_id_index` (`creator_id`),
  KEY `archive_user_id_index` (`archive_user_id`),
  KEY `guid_index` (`guid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sprint`
--

LOCK TABLES `sprint` WRITE;
/*!40000 ALTER TABLE `sprint` DISABLE KEYS */;
INSERT INTO `sprint` VALUES (1,'64b946dee6a14782996e931bc5abf4e8','2013-08-17 09:31:38',0,NULL,'Andaily 0.1','2013-08-29','2013-08-30','FINISHED','2013-08-29 00:16:00','2013-08-29 00:30:41',NULL,NULL,'OK. this is the first bll.a<br />\r\n&nbsp;<br />\r\nscrum.sad<br />\r\nsfwe<br />\r\nwefwefsf111111<a href=\"http://asfdds.com\">111111111</a>',5,0,3),(2,'56b95a8b9a4a49ab9c98cbf4086bf952','2013-08-17 09:32:37',0,NULL,'Andaily 0.2','2013-08-22','2013-08-31','PENDING','2013-08-22 00:01:44',NULL,NULL,NULL,'<p>safsaf<strong>asfsf</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li><strong>safwasf</strong></li>\r\n</ol>\r\n\r\n<p><strong>​sfwfewfesdf</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n',5,0,3),(3,'a6110f3206c544f89366a96fd8c7f584','2013-08-23 00:54:55',1,NULL,'afsdfwefsdf','2013-08-23','2013-08-24','CREATED','2013-08-23 00:55:10',NULL,NULL,NULL,'test',5,0,3),(4,'937ca6dc485c41f6a66c605cf340dc95','2013-08-27 23:33:56',0,NULL,'Andaily 0.2.1','2013-08-28','2013-09-05','PENDING','2013-09-03 23:06:05',NULL,NULL,NULL,'<strong>Think module codes</strong>',5,0,3),(5,'8d04a0ab4aa14b23814df398a2dcf74b','2013-08-29 01:16:33',0,NULL,'Andaily Developer 0.1','2013-08-29','2013-09-15','FINISHED','2013-08-29 01:16:51','2013-10-02 15:51:28',NULL,NULL,'<em>The developer moduel first scrum.</em><br />\r\n<br />\r\nSupport baisc function for monitor the development tasks.',5,0,3),(6,'0c4fb3f274a940e6b82e82b0e10b687d','2013-09-02 01:01:42',0,NULL,'test sprint1122','2013-09-04','2013-09-05','FINISHED','2013-09-04 00:12:50','2013-09-04 00:13:30',NULL,NULL,'tesste',5,0,3),(7,'15279b3104884dcaacd84218d28708fb','2013-09-02 01:02:03',0,NULL,'test sprint9999','2013-09-02','2013-09-13','CREATED',NULL,NULL,NULL,NULL,'testedfsdf',5,0,3),(8,'5dae5f29fdf34526a88b727bd0ce9673','2013-09-04 00:19:50',1,NULL,'testaaaa','2013-09-04','2013-09-05','CREATED',NULL,NULL,'2013-09-04 00:20:22',NULL,'testsss',5,0,3),(9,'10236f7c90864547acfd5fc0d7200578','2013-09-04 00:20:40',0,NULL,'testing ....','2013-09-04','2013-09-13','FINISHED','2013-09-04 00:20:52','2013-09-04 00:21:54',NULL,NULL,'test',5,0,3),(10,'13ba304bffe84017b11bf4636b08c0bb','2013-09-04 00:22:56',0,NULL,'testafasweewwe','2013-09-04','2013-09-07','FINISHED','2013-09-04 00:23:16','2013-09-04 00:23:27',NULL,NULL,'afssdfdsf',5,0,3),(11,'c224060ab8a34a6db0a85d7713acd09e','2013-09-21 22:55:28',0,NULL,'test deadline sprint','2013-09-21','2013-09-22','FINISHED','2013-09-21 22:56:44','2013-09-21 23:07:55',NULL,NULL,'test sprint for deadline',5,0,3),(12,'099b7147ef0a45fbbfd77cde635e72a2','2013-09-29 21:00:50',0,NULL,'Andaily Developer 0.2','2013-10-09','2013-10-23','FINISHED','2013-10-09 15:07:57','2013-11-13 22:27:14',NULL,NULL,'Go on developing Andaily Developer open soure project, in the sprint, we will finish the tasks as follow:\r\n<ol>\r\n	<li>Move the Andaily Developer codes from Andaily project, it will be a independent project. at the same time, keep the moved codes in Andaily project(do not use remove it).</li>\r\n	<li>Implement Project module actions. for example: Project management, Refer project with backlog,sprint, project memeber managment...</li>\r\n	<li>Do the remain tasks from &lt;Andaily Developer 0.1&gt; sprints</li>\r\n	<li>Implement documents action. Allow use upload and download backlog document and so on;</li>\r\n	<li>Check, test and upgrade the two sprints finished&nbsp;actions.</li>\r\n	<li>Allow use move created task to another sprint</li>\r\n</ol>\r\n',5,0,3),(13,'0fb95a12e90940d3a77aa00d0b704997','2013-09-29 21:09:24',0,NULL,'Andaily Developer 0.3(Security)','2013-11-16','2013-12-16','FINISHED','2013-11-16 11:06:27','2014-05-28 17:46:39',NULL,NULL,'In the sprint, we will add security for the project, includ tasks: login/logout; define roles(Product owner,Scrum master,Team member); different role show reference menu and actions; ......',5,0,3),(14,'d16cfedc0a2546e8a9c318ceeff6f993','2013-11-06 23:15:06',0,NULL,'gecko-0.1','2013-11-22','2013-11-30','CREATED',NULL,NULL,NULL,NULL,'teaf',1,0,3),(15,'8d59b466dfa947ecb108a7ead2e3213a','2013-11-16 12:19:56',1,NULL,'test3333','2013-11-16','2013-11-22','CREATED',NULL,NULL,'2013-11-16 12:23:51',NULL,'test',2,0,4),(16,'0108df906ac440a68970e400eb73d9e8','2013-11-16 12:20:19',0,NULL,'Test3232','2013-11-16','2013-11-23','CREATED',NULL,NULL,NULL,NULL,'asfsadff',2,0,4),(17,'bc36a164c92a481c8c7bdde5db94d44b','2013-11-20 22:03:16',0,NULL,'Andaily Developer 0.4','2014-06-04','2014-06-30','PENDING','2014-06-04 10:10:42',NULL,NULL,NULL,'Implement more sprint/task management',5,1,3),(18,'ad9655e1aa324acb820924b5a1397965','2014-05-26 10:53:45',0,59,'test1','2014-05-26','2014-05-31','CREATED',NULL,NULL,NULL,NULL,'test',6,0,4),(19,'090a374ef4e5442c88e2d95f19770f86','2014-05-28 16:59:22',0,61,'Team sprint','2014-05-28','2014-05-31','CREATED',NULL,NULL,NULL,NULL,'ok, test it',1,0,3),(20,'1272aad53bc64ddbb35bf7967e607343','2014-06-12 15:00:53',0,59,'Sprint 1','2014-06-12','2014-06-18','PENDING','2014-06-12 15:01:22',NULL,NULL,NULL,'OK, our team first sprint',2,0,5);
/*!40000 ALTER TABLE `sprint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sprint_meeting`
--

DROP TABLE IF EXISTS `sprint_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sprint_meeting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `meeting_date` date DEFAULT NULL,
  `type_` varchar(255) DEFAULT NULL,
  `content` text,
  `sprint_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `sprint_id_index` (`sprint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sprint_meeting`
--

LOCK TABLES `sprint_meeting` WRITE;
/*!40000 ALTER TABLE `sprint_meeting` DISABLE KEYS */;
INSERT INTO `sprint_meeting` VALUES (20,'0e587c9a7fa742bda15e4dbc9a8a3b3c','2013-10-01 17:27:00',0,'2013-10-01','DAILY_STANDING','okokok',5),(21,'a9ae0015a3f342259a21d46ee9a243c0','2013-10-01 17:45:55',0,'2013-10-01','DAILY_STANDING','editor.getData()asfasf',5),(22,'4f5811ed01434f89be82185d22d06ae1','2013-10-01 17:52:04',0,'2013-09-30','DAILY_STANDING','Status:&nbsp;<br />\r\n<br />\r\n<br />\r\nChallenge:<br />\r\n<br />\r\n<br />\r\nImport updates:<br />\r\n&nbsp;',5),(23,'ad82835fd54e4e898adf8de347f0243a','2013-10-01 21:38:19',0,'2013-09-29','DAILY_STANDING','Status: #23 finished<br />\r\n<br />\r\nChallenge: no',5),(24,'61cdfc743c18411899574c2112326cae','2013-10-01 21:54:06',0,'2013-09-28','SPRINT_PLANNING','Start to do the sprint',5),(25,'fd40368b7dac4fd582191b71f077e36b','2013-10-02 14:29:21',0,'2013-10-02','SPRINT_REVIEW','review',5),(26,'063524a098c74179abce855b79c8014d','2013-10-02 14:29:37',0,'2013-10-02','RETROSPECTIVE','retrospective meeting<br />\r\n<br />\r\nmeetingSprint',5),(27,'a2781b99664e46c48db86a8c81306b3c','2013-10-02 14:38:09',0,'2013-10-02','DAILY_STANDING','asfdsdfsd',5),(28,'f21d5f867515480b82bc9fef72e92652','2013-10-02 14:43:19',0,'2013-10-02','DAILY_STANDING','asfdddddddddddddddddddddddddddddddd',5),(29,'32a18e4227604cf884285b27540eb7a2','2013-10-02 14:45:18',0,'2013-09-30','DAILY_STANDING','sffffffffffffffffffff',5),(30,'272b50d29f9a40d3a770dd32fafb127f','2013-10-02 14:46:48',0,'2013-09-28','RETROSPECTIVE','sdddddddddddddddddd<strong>OKOKOK</strong>',5),(31,'d8c5078d52c242fca5c4142f7353ed98','2013-10-02 14:53:55',0,'2013-10-01','SPRINT_PLANNING','sfdfafsfsf',5),(32,'c175460b15e5446eb841e8b500b231d5','2013-10-02 14:54:30',0,'2013-10-01','RETROSPECTIVE','ssssssssssssssssssssssssssss',5),(33,'489f83b7a72e4210ac8d807458fc3e34','2013-11-11 23:08:41',0,'2013-11-11','DAILY_STANDING','sadffsddf',14),(34,'d58a4141684e4cd3a042ef8706f51846','2013-11-16 20:33:41',0,'2013-11-16','RETROSPECTIVE','Finish the sprint',12);
/*!40000 ALTER TABLE `sprint_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sprint_meeting_developer`
--

DROP TABLE IF EXISTS `sprint_meeting_developer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sprint_meeting_developer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `meeting_id` int(11) DEFAULT NULL,
  `developer_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `developer_id_index` (`developer_id`),
  KEY `meeting_id_index` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sprint_meeting_developer`
--

LOCK TABLES `sprint_meeting_developer` WRITE;
/*!40000 ALTER TABLE `sprint_meeting_developer` DISABLE KEYS */;
/*!40000 ALTER TABLE `sprint_meeting_developer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sprint_task`
--

DROP TABLE IF EXISTS `sprint_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sprint_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `name_` varchar(255) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `estimate_time` int(11) DEFAULT '0',
  `actual_used_time` int(11) DEFAULT '0',
  `sprint_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'CREATED',
  `pending_time` datetime DEFAULT NULL,
  `executor_id` int(11) DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `cancel_time` datetime DEFAULT NULL,
  `cancel_user_id` int(11) DEFAULT NULL,
  `priority` varchar(255) DEFAULT 'DEFAULT',
  `urgent` tinyint(1) DEFAULT '0',
  `backlog_id` int(11) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `finish_comment` varchar(255) DEFAULT NULL,
  `larger_max_time` tinyint(1) DEFAULT '0',
  `number_` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `creator_id_index` (`creator_id`),
  KEY `sprint_id_index` (`sprint_id`),
  KEY `executor_id_index` (`executor_id`),
  KEY `cancel_user_id_index` (`cancel_user_id`),
  KEY `backlog_id_index` (`backlog_id`),
  KEY `guid_index` (`guid`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sprint_task`
--

LOCK TABLES `sprint_task` WRITE;
/*!40000 ALTER TABLE `sprint_task` DISABLE KEYS */;
INSERT INTO `sprint_task` VALUES (1,'26a6830ffc0741a4b86ec6ed7e6e5e8c','2013-08-18 14:42:29',0,'Sprint task form',58,180,180,2,'FINISHED','2013-09-29 22:44:10',NULL,'2013-09-29 22:44:20',NULL,NULL,'DEFAULT',0,NULL,'<p>asfsf</p>\r\n',NULL,0,1),(2,'1fae9ec7f7bd4aa0927d9ea8aca99fab','2013-08-18 14:49:59',0,'190. Integration test auto start thing scheduler, it\'s not work  ',58,240,240,2,'FINISHED','2013-09-29 22:43:40',NULL,'2013-09-29 22:43:48',NULL,NULL,'DEFAULT',0,NULL,'OK.&nbsp;<br />\r\nNo, test it .<br />\r\n<a href=\"http://www.andaily.com\" target=\"_blank\">http://www.andaily.com</a>',NULL,0,2),(3,'c5b3980a5b91490ba7f5591110aba620','2013-08-18 14:51:56',1,'Sprint form validator ',58,240,0,2,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',1,NULL,'sfdasf<br />\r\nsfewf<br />\r\nsf<br />\r\nwefsdfds<br />\r\n<strong>sfwefsf<br />\r\n<br />\r\nd</strong><br />\r\n&nbsp;',NULL,0,3),(4,'bd94b83de0c44ca0b4054bcfaa91709b','2013-08-18 15:01:20',1,'Sprint task form',58,180,0,2,'CANCELED','2013-08-19 22:43:54',NULL,NULL,'2013-08-20 22:34:30',NULL,'DEFAULT',1,NULL,'<ul>\r\n	<li>asfsf</li>\r\n</ul>\r\n',NULL,0,4),(5,'33fc3178c6b5428b889d00bd7348dfbf','2013-08-18 15:01:41',0,'monkeyk1987@gmail.com',58,60,90,1,'FINISHED','2013-08-29 00:16:05',NULL,'2013-08-29 00:16:18',NULL,NULL,'DEFAULT',0,NULL,'<p>saDDSA</p>\r\n',NULL,0,5),(6,'001e505f92ce467a92fc7396093a8862','2013-08-18 15:02:14',1,'Sprint form validator ',58,240,0,2,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',1,NULL,'',NULL,0,6),(7,'7072175119cf49a78ec0a4c8624f23e9','2013-08-18 15:05:21',0,'Sprint form validator ',58,240,240,2,'FINISHED','2013-08-18 19:18:45',NULL,'2013-08-20 21:51:49',NULL,NULL,'DEFAULT',1,NULL,'',NULL,0,7),(8,'a5bde356fe4240718af792e116acc15b','2013-08-18 17:10:17',0,'169.Count of every status task on tab pages   ',58,60,0,2,'FINISHED',NULL,NULL,'2013-08-20 21:46:54',NULL,NULL,'LOW',0,NULL,'dddddd',NULL,0,8),(9,'c850ffc30f1c4bff9b2487e42fecd540','2013-08-19 22:28:53',1,'157. Add developer-servlet.xml and try to test it  ',58,60,0,2,'CANCELED','2013-08-20 22:33:32',NULL,NULL,'2013-08-20 22:33:40',NULL,'DEFAULT',0,NULL,'<strong>sadsds</strong>',NULL,0,9),(10,'074decc924ff487da6ce696be879bc45','2013-08-19 22:31:20',1,'asdfwfeefds',58,30,0,2,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,NULL,'<ol>\r\n	<li>safddssfd</li>\r\n	<li>wf</li>\r\n	<li>ds</li>\r\n	<li>wefsd</li>\r\n</ol>\r\n',NULL,0,10),(11,'4256c3dc79da49edb59e6bfe5d674b6f','2013-08-19 23:27:41',0,'Fix relation path issue',58,30,30,2,'FINISHED','2013-08-28 00:17:39',NULL,'2013-09-29 22:44:15',NULL,NULL,'DEFAULT',1,NULL,'fix is as soon as possible',NULL,0,11),(12,'d4de9ea8fb13481fb9a70da798e2d91f','2013-08-20 21:51:35',0,'Refer the current user for Sprint,SprintTask',58,60,60,2,'FINISHED','2013-08-20 22:34:14',NULL,'2013-09-29 14:41:47',NULL,NULL,'DEFAULT',0,NULL,'Give me the create user, cancel user and so on..',NULL,0,12),(13,'8d6431255e154e1c9d0be3079a97b638','2013-08-20 22:17:05',1,'asfwfewfewef',58,30,0,2,'CANCELED','2013-08-20 22:17:13',NULL,NULL,'2013-08-20 22:17:19',NULL,'DEFAULT',0,NULL,'sf',NULL,0,13),(14,'1be6f35869ff468c80d20778c2117b18','2013-08-20 22:36:20',1,'monkeyking1987@126.com',58,30,0,2,'CREATED',NULL,NULL,NULL,NULL,NULL,'HIGH',0,NULL,'',NULL,0,14),(15,'f17f664c6f45426bb1dc0047e28830da','2013-08-20 22:58:34',0,'Add developer-servlet.xml and try to test it  ',58,30,30,2,'FINISHED','2013-08-20 23:01:23',NULL,'2013-09-29 22:43:19',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,15),(16,'8aa885b1036d4e9880d61f4e1e764e80','2013-08-20 22:58:52',0,'Add developer decorator pages  ',58,60,0,2,'CANCELED','2013-08-23 01:08:03',NULL,NULL,'2013-08-27 23:31:33',NULL,'DEFAULT',0,NULL,'asfdfsdasd<br />\r\n<strong>fweqweffwsdafsdsfd</strong>',NULL,0,16),(17,'c152764b2f714e379eeead50681eb53b','2013-08-23 01:06:03',1,'6.Add forgot password action     ',58,60,0,2,'CANCELED','2013-08-23 01:06:16',NULL,NULL,'2013-08-23 01:06:31',NULL,'DEFAULT',0,NULL,'6.Add forgot password action &nbsp; &nbsp;&nbsp;',NULL,0,17),(18,'9f5259ef361b487db1366d11c83c5738','2013-08-27 23:35:18',0,'Design Think domain and refer domains',58,120,0,4,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,NULL,'Domain list:\r\n<ol>\r\n	<li>​Think</li>\r\n	<li>ThinkDetails</li>\r\n	<li>ThinkVote</li>\r\n</ol>\r\n',NULL,0,18),(19,'015276d6a5734f3ea0648e5a959d9202','2013-08-27 23:58:54',0,'ScrumSecurityChecker',58,30,0,4,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,NULL,'asfsf',NULL,0,19),(20,'a7af1f946ea8480e95fb94d5807581a3','2013-08-29 01:18:24',0,'160. Backlog overview page action ',58,60,150,5,'FINISHED','2013-09-02 01:20:35',NULL,'2013-09-10 21:29:30',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,20),(21,'75c99c8f4c4d4d03a168cf6f53d8b1ca','2013-08-29 01:18:44',0,'164. Backlog form',58,120,120,5,'FINISHED','2013-09-02 01:20:26',NULL,'2013-09-08 11:46:53',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,21),(22,'42ef41ac237d45eba0dbe2d41f220885','2013-08-29 01:19:02',0,'165. Sprint overview  ',58,120,120,5,'FINISHED','2013-08-29 01:33:00',NULL,'2013-09-02 00:47:39',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,22),(23,'16487df734864e0ba33e9f2f5c022648','2013-08-29 01:19:18',0,'167. Add tip after save action on page',58,60,30,5,'FINISHED','2013-08-30 22:38:18',NULL,'2013-09-02 01:07:15',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,23),(24,'80911da1c79c4e58bb93f423c07cce34','2013-08-29 01:19:35',0,'171. Refer the action user to Sprint,SprintTask and Backlog',58,60,60,13,'FINISHED','2014-05-23 16:52:40',NULL,'2014-05-26 11:47:18',NULL,NULL,'DEFAULT',0,NULL,'','Include add log',0,24),(25,'db5be6fe8a064fb18a7a5ba6c15743f4','2013-08-29 01:19:51',0,'173.Group show Sprint on task overview select element',58,30,30,5,'FINISHED','2013-08-29 01:29:05',NULL,'2013-08-29 01:32:18',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,25),(26,'c6a856c519db4bd6a562b74d78c384a9','2013-08-29 01:22:17',0,'157. Add developer-servlet.xml and try to test it',58,30,30,5,'FINISHED','2013-08-29 01:22:51',NULL,'2013-08-29 01:23:20',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,26),(27,'1f54d56833b441b5bafc4da5d5ff6004','2013-08-29 01:22:31',0,'158. Add developer decorator pages',58,60,30,5,'FINISHED','2013-08-29 01:22:42',NULL,'2013-08-29 01:23:10',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,27),(28,'152db99db2184cfab9f5a0e1867bff3f','2013-08-29 01:24:03',0,'159. Develop dashboard action(load data,  search by page ...)',58,120,240,5,'FINISHED','2013-08-29 01:28:59',NULL,'2013-08-29 01:32:08',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,28),(29,'3bd4629553954de4a11bcf3c0c1b493e','2013-08-29 01:24:15',0,'161. Sprint form ',58,180,180,5,'FINISHED','2013-08-29 01:28:55',NULL,'2013-08-29 01:31:05',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,29),(30,'32f7c027b6ff45e98caa4f9ec6a7fecf','2013-08-29 01:24:27',0,'162. Sprint task form ',58,180,180,5,'FINISHED','2013-08-29 01:28:40',NULL,'2013-08-29 01:30:55',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,30),(31,'c90f556b54094570a910c8a145289cd8','2013-08-29 01:24:38',0,'163. Developer page link actions',58,180,180,5,'FINISHED','2013-08-29 01:28:34',NULL,'2013-08-29 01:30:44',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,31),(32,'59db15b1d15b4741a98189638e6714ca','2013-08-29 01:24:54',0,'166. Sprint form validator ',58,60,60,5,'FINISHED','2013-08-29 01:28:28',NULL,'2013-08-29 01:30:32',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,32),(33,'169e7cc53f7f4cfca8145e4dc05d3996','2013-08-29 01:25:08',0,'168. Toggle menu active when click different urls ',58,30,30,5,'FINISHED','2013-08-29 01:28:25',NULL,'2013-08-29 01:30:18',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,33),(34,'f16772ed703a45f4b5e398d648f1d36c','2013-08-29 01:25:19',0,'169. Count of every status task on tab pages ',58,60,60,5,'FINISHED','2013-08-29 01:28:22',NULL,'2013-08-29 01:30:06',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,34),(35,'4173ff5f8133470caa5d1b7f5896dbd8','2013-08-29 01:25:33',0,'170. Add tooltip action',58,30,30,5,'FINISHED','2013-08-29 01:26:32',NULL,'2013-08-29 01:29:50',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,35),(36,'29c67853885c4fa6b71c298fe13b9772','2013-08-29 01:25:48',0,'172.Sprint develop home page actions  ',58,120,120,5,'FINISHED','2013-08-29 01:26:26',NULL,'2013-08-29 01:29:23',NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,36),(37,'e82428e2c1c14650977cc900aab5aad8','2013-08-29 01:42:04',0,'174.Show the finished task, the finished sprint time difference ',58,60,60,5,'FINISHED','2013-08-29 01:42:23',NULL,'2013-08-30 22:31:58',NULL,NULL,'DEFAULT',0,NULL,'Busincess requirement:\r\n<ol>\r\n	<li>If the finished task used time &gt; or &lt; estimate time , show the time difference.e.g. &nbsp;estimate time is 1 hour, used time is 1.5 hour, then&nbsp;<strong>Actual Used&nbsp;</strong>column show: <strong><em>1.5(+0.5)</em></strong>;if the used time is 0.5 hour, then&nbsp;<strong>Actual Used&nbsp;</strong>column show <strong><em>0.5(-0.5)</em></strong></li>\r\n	<li>Finished Sprint tooltip show the time difference as the task rule.</li>\r\n</ol>\r\n',NULL,0,37),(38,'9c9dc30811de45ac9709496ded178ef4','2013-08-30 22:37:36',0,'Show the Sprint activities',58,180,0,17,'CREATED','2014-05-28 17:46:01',61,NULL,NULL,NULL,'LOW',0,NULL,'<ol>\r\n	<li>On the &#39;Task&#39; page add &quot;activities&#39; submenu to &#39;Action&quot; menu, always show the submenu no matter what status of the Sprint</li>\r\n	<li>When click the submenu , go to the Sprint activities page. One activites is look like &quot;Mkk already finish the task &lt;task name&gt; on 2013-09-03 23:34&quot;.</li>\r\n</ol>\r\n',NULL,0,38),(39,'3c1be01d4c1b4db7b840ab44a810d3cf','2013-09-02 00:47:23',0,'176.Sprint overview page actions(add task menu)  ',58,60,60,5,'FINISHED','2013-09-02 00:47:33',NULL,'2013-09-04 00:28:33',NULL,NULL,'DEFAULT',0,NULL,'Check all the sprint action on the overview page, include add &#39;task&#39; menu&nbsp;',NULL,0,39),(40,'e1f37d331cdc43698b9d8f389a8c5fde','2013-09-02 00:58:31',0,'ttttttttttttttttttttttttttttttttttt',58,30,0,4,'PENDING','2013-11-13 22:14:54',NULL,NULL,NULL,NULL,'DEFAULT',0,NULL,'',NULL,0,40),(41,'02a09d6bb7a04bcfbfd7d27e75a6d0fa','2013-09-02 01:01:03',0,'ssssssssssssssssssssssssssss',58,30,90,4,'FINISHED','2013-11-13 21:56:48',NULL,'2013-11-13 22:13:00',NULL,NULL,'DEFAULT',0,NULL,'sfsfsf','',0,41),(42,'f6d809180cc9492187369815bd3b7f62','2013-09-02 01:09:10',0,'Design project domain',58,90,90,12,'FINISHED','2013-10-10 23:22:13',NULL,'2013-10-16 23:23:48',NULL,NULL,'DEFAULT',0,NULL,'Design Project domain , include refer to Sprint and so on',NULL,0,42),(43,'9fcb624763794dfcbbf021301f106e95','2013-09-02 01:09:47',0,'sfdafsf',58,240,240,4,'FINISHED','2013-11-13 21:58:38',NULL,'2013-11-13 21:58:48',NULL,NULL,'DEFAULT',0,NULL,'','4',1,43),(44,'8f7122a6489243b592ff9fcf71453adc','2013-09-02 01:13:45',0,'safwfwef',58,30,240,4,'FINISHED','2013-11-12 22:56:56',NULL,'2013-11-13 21:57:01',NULL,NULL,'DEFAULT',0,NULL,'sfsf','4',1,44),(45,'0717ef3e36cd4ba5aded2c7b8c205038','2013-09-03 23:00:59',0,'Use STRender replace Sprint details,Task details text',58,60,90,12,'FINISHED','2013-11-11 22:27:12',NULL,'2013-11-12 22:05:08',NULL,NULL,'DEFAULT',0,NULL,'Do not use append string in <strong>SprintDto </strong>and <strong>SprintTaskDto</strong>, use <strong>STRender </strong>render the text from template files&nbsp;<br />\r\n<em>Maybe use dialog replace popuar in future, i think it is much better</em>.',NULL,0,45),(46,'311a64dbf778401797f750dfb185c6a0','2013-09-05 00:34:16',0,'Test Sprint,SprintTask backlog is work or not',58,60,60,5,'FINISHED','2013-09-09 23:55:54',NULL,'2013-09-10 22:47:26',NULL,NULL,'DEFAULT',0,NULL,'After finish Backlog form,overview tasks, we need to test the backlog refer to the sprint,task is work normally.',NULL,0,46),(47,'7a19b91ae3194fcdb2ccdabcd0f15c4c','2013-09-09 23:55:01',1,'asfdsffsdfewewsd',58,30,0,7,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,2,'asfdsffsdfewewsdasfdsffsdfewewsdasfdsf fsdfewewsd&nbsp;style=&quot;vertical-align: middle;&quot;&nbsp;style=&quot;vertical-align: middle;&quot;',NULL,0,47),(48,'9478b06f7d1642a29ba8647fa64b8351','2013-09-10 00:26:55',0,'Backlog add estimateTime field',58,60,60,5,'FINISHED','2013-09-10 21:29:55',NULL,'2013-09-11 23:51:54',NULL,NULL,'DEFAULT',0,NULL,'Backlog domain add <em>estimateTime&nbsp;</em>field, the same as Sprint estimateTime field; the field max hours is <strong>16 </strong>, add refer to show on sprint-form and &nbsp;task-form pages',NULL,0,48),(49,'0fef07f0d4df45e784c30515a386a8fc','2013-09-10 22:31:18',0,'需要添加用户的引用到当前的操作, 当创建task, sprint, backlog等.',58,90,0,7,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,1,'需要添加用户的引用到当前的操作, 当创建task, sprint, backlog等.',NULL,0,49),(50,'2bebe69f9d1843adaad6395d64bb5e45','2013-09-11 23:53:23',0,'Sprint form dynamic show total backlog estimate times',58,30,60,5,'FINISHED','2013-09-11 23:53:28',NULL,'2013-09-12 22:40:51',NULL,NULL,'DEFAULT',0,NULL,'Sprint form dynamic show total backlog estimate times, <strong>Total estimate(hour): 4</strong>',NULL,0,50),(51,'0608d126297543079d4f0a0da5b85f05','2013-09-12 22:40:35',0,'Sprint overview show Backlog informations',58,90,90,5,'FINISHED','2013-09-12 22:40:43',NULL,'2013-09-12 23:26:57',NULL,NULL,'DEFAULT',0,NULL,'If the sprint have one or more backlog references, add a icon(<em>icon-tags</em>) on the row last,<br />\r\nwhen click the icon, show a dialog, the dialog content is the backlogs, show on a table.',NULL,0,51),(52,'a0ce295628a84bfe890c6271d6d3a3e6','2013-09-12 22:43:14',0,'Task overview show backlog content',58,60,60,5,'FINISHED','2013-09-12 22:43:18',NULL,'2013-09-16 00:33:53',NULL,NULL,'DEFAULT',0,NULL,'If the task refer to a backlog, show a icon(<em>icon-tag</em>) on the row last position, click the icon open popuar show the backlog content',NULL,0,52),(53,'2543106940064e768ce456678d85cba0','2013-09-12 23:33:51',0,'Per overview footer show total times on the task overview',58,60,60,5,'FINISHED','2013-09-12 23:34:17',NULL,'2013-09-17 00:52:57',NULL,NULL,'DEFAULT',0,NULL,'Include tabs: pending, created,finsihed,canceled, all tasks &nbsp;5 overviews',NULL,0,53),(54,'2b1e1bc7442a44ad8f251afd87ebd54b','2013-09-16 00:31:50',0,'Test backlog',58,60,0,7,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,5,'High ...... bugs (<strong>1</strong>)',NULL,0,54),(55,'4be8535a52e34ff8a7aaffa71c825f9d','2013-09-16 01:00:49',0,'zcsddsds',58,30,0,7,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,NULL,'afsddfsfd',NULL,0,55),(56,'5edb72de86e544ec8d7b369992edc010','2013-09-17 00:49:08',0,'Sprint add real time time report',58,90,180,17,'FINISHED','2014-06-10 16:00:07',58,'2014-06-12 14:28:09',NULL,NULL,'DEFAULT',0,NULL,'At a sub-menu to the action menu &quot;<strong>Time report</strong>&quot;, &nbsp;it will be dynamic show the sprint time status: total estimate time, used time, pending time, created time and so on.<br />\r\n<br />\r\nI will do it after project refer to Developer.','It is a little difficult',0,56),(57,'8e6f3649a131432faebb0078fed51750','2013-09-17 00:51:13',0,'Design SprintMeet domain',58,60,60,5,'FINISHED','2013-09-17 00:51:18',NULL,'2013-09-24 00:01:48',NULL,NULL,'DEFAULT',0,NULL,'Sprint meet, &nbsp;include meet type, join users, content, date fields...',NULL,0,57),(58,'652094de05034e3a9e6994811bab50b2','2013-09-17 00:52:32',0,'Change all sprint end date to deadline field',58,30,30,5,'FINISHED','2013-09-17 00:52:37',NULL,'2013-09-21 23:08:24',NULL,NULL,'DEFAULT',0,NULL,'Include sql column name',NULL,0,58),(59,'80eeb9a164884ddd98adb74f393e0bfd','2013-09-21 22:58:03',0,'tadsdfs',58,120,120,11,'FINISHED','2013-09-21 22:59:41',NULL,'2013-09-21 23:00:04',NULL,NULL,'DEFAULT',1,NULL,'fasfds',NULL,0,59),(60,'a0982994604e4bb493a4acf3d1812d74','2013-09-22 22:55:02',0,'Finish task time maybe larger than 4 hours',58,60,90,12,'FINISHED','2013-11-11 22:28:53',NULL,'2013-11-13 22:14:21',NULL,NULL,'LOW',0,NULL,'Find how to fix the design issue and resolve it.','',0,60),(61,'3296bf8444f64fa0918ccadd4f6ffae0','2013-09-22 23:56:43',0,'Add developer domain',58,60,60,5,'FINISHED','2013-09-22 23:57:21',NULL,'2013-09-23 00:40:20',NULL,NULL,'DEFAULT',0,NULL,'It is a subclass of User, which have a field call&nbsp;<strong>ScrumTerm </strong>.&nbsp;',NULL,0,61),(62,'bcf61e08627943be8ac46de478b3db63','2013-09-22 23:57:11',0,'Add ScrumComment domain',58,30,30,5,'FINISHED','2013-09-22 23:57:16',NULL,'2013-09-23 22:48:48',NULL,NULL,'DEFAULT',0,NULL,'who on what time , do what.',NULL,0,62),(63,'7685b10d5cd54c5bb1cbc1d03c108ca2','2013-09-24 00:01:37',0,'Create Burn down chart resolver ',58,180,180,5,'FINISHED','2013-09-24 00:01:43',NULL,'2013-09-29 14:46:51',NULL,NULL,'DEFAULT',0,NULL,'A resolver for burn down chart , return all reference chart data&nbsp;',NULL,0,63),(64,'c127492cc4514c918a6ae47e69b9dbe3','2013-09-24 22:06:32',0,'Sprint meeting form action',58,180,180,5,'FINISHED','2013-09-24 22:06:36',NULL,'2013-10-01 17:46:50',NULL,NULL,'DEFAULT',0,NULL,'Sprint meeting form action: &nbsp;add/edit/validation<br />\r\n<br />\r\n&nbsp;',NULL,0,64),(65,'3c81564e1ddb430fbf41e264163c5cf9','2013-09-28 00:55:47',0,'Show burn down chart details',58,120,120,5,'FINISHED','2013-09-29 15:11:51',NULL,'2013-09-29 22:52:46',NULL,NULL,'DEFAULT',0,NULL,'Show the burn down chart details when click details icon on the developer page, the details includes full chart and time report.',NULL,0,65),(66,'4cb7785ff3e74900a36dbe2b19e7d1a9','2013-09-29 20:32:39',0,'Show the latest 5 meetings on developer home page',58,60,60,5,'FINISHED','2013-09-29 22:53:43',NULL,'2013-10-01 21:55:28',NULL,NULL,'DEFAULT',0,NULL,'FYI, &nbsp;<br />\r\nOn the developer home page, show the latest 5 meetings as list, and add a more link at the bottom, when click the more link, go to the sprint meeting overview.&nbsp;<br />\r\n<br />\r\nthe content look like as below:\r\n<ul>\r\n	<li>2013-09-12 &nbsp;(Daily standing)</li>\r\n	<li>2013-09-11 &nbsp;(Daily standing)</li>\r\n	<li>2013-09-11 &nbsp;(Sprint planning)</li>\r\n	<li>...</li>\r\n</ul>\r\n',NULL,0,66),(67,'ef3e8b1905c2421e9265a89f3e5ace99','2013-09-29 20:39:49',0,'Sprint meeting overview',58,120,120,5,'FINISHED','2013-10-01 17:47:06',NULL,'2013-10-02 14:55:26',NULL,NULL,'DEFAULT',0,NULL,'Show all the &nbsp;sprint meeting on a page(include pagination), the meeting order by meetin date desc.<br />\r\nthe row meeting content include: &nbsp;meeting date;meeting type, and part of the content.<br />\r\nwhen click the meeting date, show two menus: edit and details.',NULL,0,67),(68,'bae75eb427cd4c13881cfb45589b77a9','2013-09-29 20:44:52',0,'Edit sprint meeting action',58,30,30,5,'FINISHED','2013-10-01 17:49:00',NULL,'2013-10-02 15:50:50',NULL,NULL,'DEFAULT',0,NULL,'Click the edit meun on the meeting overview page, open a sprint meeting form popup, the popup is same as the add meeting form, then edit it &nbsp;and save it.',NULL,0,68),(69,'173c2150bd474c2bb79b1243188968bb','2013-09-29 21:03:17',0,'Show sprint meeting details action',58,30,30,5,'FINISHED','2013-10-01 17:49:08',NULL,'2013-10-02 15:50:56',NULL,NULL,'DEFAULT',0,NULL,'When click the &#39;details&#39; menu on the meeting overview page, show a popup, the content is the meeting date,content,type and so on.',NULL,0,69),(70,'e4e56303b06a44eabd03d1563db0f6ac','2013-10-01 22:17:04',0,'Show legend when transfer to All task tab on developer page',58,30,30,12,'FINISHED','2013-10-09 15:09:58',NULL,'2013-10-09 15:19:34',NULL,NULL,'DEFAULT',0,NULL,'Show different color for diffent status task legend on the right area when show &#39;All task&#39; tab.',NULL,0,70),(71,'554fd18d15db4e489d88f2f231766db7','2013-10-09 15:16:32',0,'Project form action',58,120,120,12,'FINISHED','2013-10-16 23:23:40',NULL,'2013-10-29 22:06:57',NULL,NULL,'DEFAULT',0,NULL,'Add/edit project form.',NULL,0,71),(72,'8c1ddc65dc7946cd842536b9fe6f98df','2013-10-09 15:18:57',0,'Allow use move created task to another sprint',58,120,120,12,'FINISHED','2013-10-09 15:19:02',NULL,'2013-10-09 22:59:36',NULL,NULL,'DEFAULT',0,NULL,'Allow use move created task to another sprint;<br />\r\n<br />\r\nOnly <strong>canceled </strong>task allow to move. the target sprint status is <strong>Created </strong>or <strong>Pending</strong>',NULL,0,72),(73,'48abc5769638402fa34a89a2a555f233','2013-10-09 23:01:20',0,'Move the Andaily Developer codes from Andaily project',58,180,180,12,'FINISHED','2013-10-09 23:01:45',NULL,'2013-10-10 23:15:12',NULL,NULL,'HIGH',0,NULL,'Move it and test it , also keep old codes in Andaily project;<br />\r\n<br />\r\nCheck in the new codes to Git OSC and so on.',NULL,0,73),(74,'d4bd294cd9074705a90872f9470c4c64','2013-10-14 22:28:42',0,'Config andaily-developer jenkins in CloudBees',58,60,60,12,'FINISHED','2013-10-14 22:28:48',NULL,'2013-10-14 23:22:21',NULL,NULL,'DEFAULT',0,NULL,'Config andaily-developer jenkins in CloudBees',NULL,0,74),(75,'27099c38205649eda1dabe1a0b89b3fe','2013-10-16 23:25:06',0,'Project overview',58,90,90,12,'FINISHED','2013-10-16 23:25:11',NULL,'2013-10-29 22:43:19',NULL,NULL,'DEFAULT',0,NULL,'Project overview, include paginated; search filter...',NULL,0,75),(76,'354e93fc96bd47b29e2a45752a2c9a20','2013-10-29 22:32:54',0,'Project overview, backlog overview add projectGuid condition when query',58,90,90,12,'FINISHED','2013-10-29 22:33:00',NULL,'2013-10-31 22:58:02',NULL,NULL,'DEFAULT',0,NULL,'When query on sprint overview or backlog overview, we should be check project, and add the condition',NULL,0,76),(77,'2f33406e7ac14c838d54496ac6c39b4b','2013-10-31 22:41:02',0,'Sprint form refer to project',58,60,60,12,'FINISHED','2013-10-31 22:42:22',NULL,'2013-11-06 23:15:49',NULL,NULL,'DEFAULT',0,NULL,'If when create sprint refer a projectGuid, do not change as before, otherwise, choose a project for the new sprint',NULL,0,77),(78,'ae5bb5b3254b438199701acd69698f49','2013-10-31 22:42:07',0,'Backlog form refer to project',58,60,60,12,'FINISHED','2013-10-31 22:58:36',NULL,'2013-11-06 22:53:07',NULL,NULL,'DEFAULT',0,NULL,'When create bakclog if have <em>projectGuid </em>parameter, do not change as before.otherwise, choose a project is necessary',NULL,0,78),(79,'d98513089209498399767eba85596f0e','2013-11-11 22:11:51',0,'Task overview sprint select show project name',58,30,30,12,'FINISHED','2013-11-11 22:11:57',NULL,'2013-11-11 22:20:41',NULL,NULL,'DEFAULT',0,NULL,'Add project neme after sprint name on the task overview sprint select element',NULL,0,79),(80,'3c4172d0c187409798f56bff4648d4c2','2013-11-11 23:13:40',0,'Set a default sprint on task overview page',58,30,60,13,'FINISHED','2013-11-16 11:37:54',NULL,'2013-11-20 22:00:38',NULL,NULL,'DEFAULT',0,NULL,'If set a default sprint on task overview page, then if click &quot;Task&quot; menu directly, will set current sprint is default sprint; &nbsp;<strong>only one default sprint</strong>.','',0,80),(81,'3117616b21b743e896740ca84a19b646','2013-11-12 22:10:17',0,'afsdfewfewds',58,240,241,2,'FINISHED','2013-11-12 22:10:21',NULL,'2013-11-12 22:52:43',NULL,NULL,'DEFAULT',0,NULL,'sfdsdffds','okok',0,81),(82,'1ecba3fff48241478667bb963e316396','2013-11-12 22:12:45',0,'Finish task modal add comment field',58,60,60,12,'FINISHED','2013-11-12 22:12:49',NULL,'2013-11-13 22:14:14',NULL,NULL,'DEFAULT',0,NULL,'Finish task modal add comment input element, allow user input comment when finishing.','',0,82),(83,'c7ccabdcc8fd44108982c345ba857ab0','2013-11-13 22:25:00',0,'asfdsdf',58,30,240,2,'FINISHED','2013-11-13 22:25:04',NULL,'2013-11-13 22:25:26',NULL,NULL,'DEFAULT',0,NULL,'sfdsfd','more reason',1,83),(84,'3ba78d301edb40a892f17d8db266e8ee','2013-11-13 22:38:12',0,'Add count of meetings on sprint overview menu item',58,30,30,13,'FINISHED','2013-11-16 11:06:39',NULL,'2013-11-16 11:20:57',NULL,NULL,'DEFAULT',0,NULL,'Add count of meetings on sprint overview menu item','',0,84),(85,'2690eebfe50b463aa832ea51a3abeb7e','2013-11-13 22:39:15',0,'Add count of sprints,count of backlogs on project overview menu',58,30,30,13,'FINISHED','2013-11-16 11:20:47',NULL,'2013-11-16 11:34:49',NULL,NULL,'DEFAULT',0,NULL,'Add count of sprints,count of backlogs on project overview menu','',0,85),(86,'22ff5516adb64cae9de6696b84476816','2013-11-16 11:25:47',0,'Design Developer domain',58,90,90,13,'FINISHED','2013-11-20 22:00:45',NULL,'2013-11-21 22:16:29',NULL,NULL,'DEFAULT',0,NULL,'Design Developer domain, include reference domains: roles..','',0,86),(87,'693e9b6d2c4e40208bd7aa38e04a7990','2013-11-20 22:06:56',0,'Backlog overview add sprintGuid condition',58,60,60,17,'FINISHED','2014-06-04 10:13:24',61,'2014-06-04 14:24:34',NULL,NULL,'DEFAULT',0,NULL,'Add a backlog menu item on the sprint overview menu;&nbsp;<br />\r\nIf click the menu, go to backlog overview , only show the sprint backlogs,\r\n<div><br />\r\nIt is allow the sprint backlogs add exist new backlog(it&#39;s mean the backlog not bind any sprint yet)</div>\r\n,allow to add backlog to a pending sprint.','',0,87),(88,'e0ac7b8526754e709c0ccf9bb4f28cee','2013-11-20 22:34:18',0,'Design Team domain',58,60,60,13,'FINISHED','2013-11-20 22:35:25',NULL,'2013-11-21 22:16:24',NULL,NULL,'DEFAULT',0,NULL,'Define Team domain, a team includes: name, creator, projects and memebers.<br />\r\nThe members includes: Scrum master, scrum member and product owner roles','',0,88),(89,'469b7c9dddd44ab8870e97afd902e455','2013-11-20 22:35:20',0,'Security configuration',58,120,150,13,'FINISHED','2013-11-21 22:16:44',NULL,'2013-11-24 11:14:44',NULL,NULL,'DEFAULT',0,NULL,'Add spring security configuration<br />\r\ninclude menus on main.jsp ...','',0,89),(90,'4c9981a8bac8425aad714f11ea70dd1c','2013-11-20 22:37:07',0,'Assign task to a developer',58,60,60,17,'FINISHED','2014-06-04 17:30:03',58,'2014-06-05 10:46:01',NULL,NULL,'DEFAULT',0,NULL,'The created task add a menu call: Assign..., if click the menu, will popup a modal , choose a developer do the task.','',0,90),(91,'7985a0121bb842e2a4ed0c8455e72015','2013-11-20 22:39:46',0,'\"Do it\" menu add a confirm modal ',58,60,60,13,'FINISHED','2014-05-28 17:45:32',53,'2014-05-28 17:45:37',NULL,NULL,'DEFAULT',0,NULL,'When click &quot;Do it&quot; menu , a confirm modal will be open, the task executor will be show. Maybe the content look like &quot;Are your sure do the task now, {developer name}?&quot; . &nbsp;','',0,91),(92,'55a5f72109a2474f86b4d86d2ae09782','2013-11-23 13:23:31',0,'Super man redirect to user overview after sign in successful',58,30,30,13,'FINISHED','2014-05-21 18:12:33',NULL,'2014-05-21 18:51:37',NULL,NULL,'DEFAULT',0,NULL,'Super man redirect to user overview after sign in successful','',0,92),(93,'69969f2f38bc4024bd12bb06ac8737a3','2013-11-23 13:24:11',0,'User overview',58,60,60,13,'FINISHED','2013-11-24 11:14:26',NULL,'2013-11-25 22:53:44',NULL,NULL,'DEFAULT',0,NULL,'','',0,93),(94,'782a172aafcb492390e58696b19749d4','2013-11-23 13:24:21',0,'User form',58,90,150,13,'FINISHED','2013-11-25 23:29:19',NULL,'2013-12-03 23:51:45',NULL,NULL,'DEFAULT',0,NULL,'','Too long',0,94),(95,'7023d8a252cd4251901978305f855e5e','2013-11-24 10:51:59',0,'Remember me action',58,60,60,13,'FINISHED','2013-11-25 22:53:57',NULL,'2013-11-25 23:29:02',NULL,NULL,'DEFAULT',0,NULL,'It is same as andaily remember me','',0,95),(96,'99e73d224018460a8b3ff122439630b4','2013-11-24 10:53:50',0,'Profile action',58,120,120,13,'FINISHED','2014-05-22 16:30:11',NULL,'2014-05-23 16:42:53',NULL,NULL,'DEFAULT',0,NULL,'User profile, include update user information, change password , clean saved username/password and so on','',0,96),(97,'341255da1b7547449cdbb6924875da40','2013-11-24 11:14:17',0,'Security url pattern setting',58,90,90,13,'FINISHED','2014-05-21 18:52:21',NULL,'2014-05-22 16:24:37',NULL,NULL,'LOW',0,NULL,'Setting every url pattern of security.xml<br />\r\n<br />\r\nand test it','',0,97),(98,'6cca0b87f4ad44ce9c28d68c2cb5dd73','2013-11-25 22:55:23',0,'User overview menu action',58,60,120,13,'FINISHED','2013-12-03 23:55:55',NULL,'2013-12-05 22:56:05',NULL,NULL,'DEFAULT',0,NULL,'User overview add menu(for email filed), includes: &nbsp;Edit,enable/disable, archive','',0,98),(99,'85752288288a4ccd9503823a874df637','2013-12-03 23:57:00',0,'Team overview',58,90,90,13,'FINISHED','2013-12-05 22:56:58',NULL,'2013-12-17 22:56:36',NULL,NULL,'DEFAULT',0,NULL,'','',0,99),(100,'959d447d1f61419b89c44f4afd6f2968','2013-12-03 23:57:08',0,'Team form',58,90,90,13,'FINISHED','2013-12-05 22:57:03',NULL,'2014-05-21 14:06:11',NULL,NULL,'DEFAULT',0,NULL,'','long long time',0,100),(101,'9cc4611b81854cf9ac5dfe8e6d0c174c','2014-05-21 14:08:59',0,'Team add description field',58,30,30,13,'FINISHED','2014-05-21 14:10:30',NULL,'2014-05-21 17:47:53',NULL,NULL,'DEFAULT',0,NULL,'....','',0,101),(102,'05f0900a67074be991d3bf0f8c4836e2','2014-05-21 14:10:19',0,'Team overview actions',58,60,60,13,'FINISHED','2014-05-21 14:10:24',NULL,'2014-05-21 18:10:24',NULL,NULL,'DEFAULT',0,NULL,'Add menus: projects(num),memebers(num); Edit,Archive.','',0,102),(103,'b81c843924614180b870ad5ecabb82bb','2014-05-21 18:11:41',0,'Redesign Project domain',58,30,30,13,'FINISHED','2014-05-21 18:12:19',NULL,'2014-05-21 18:39:59',NULL,NULL,'DEFAULT',0,NULL,'Check the fields: developers and so on.','',0,103),(104,'08c32720707d43b0a7351f873e1d79b4','2014-05-23 16:50:25',0,'Different role show different data',58,120,120,13,'FINISHED','2014-05-26 15:51:47',NULL,'2014-05-26 18:20:43',NULL,NULL,'DEFAULT',0,NULL,'If i am a MEMEBER role, show the reference projects, backlogs and so on ..<br />\r\nIf i am a Master role, me too.<br />\r\n...','useful tasks',0,104),(105,'7c4f7cd72f0a496c8518b6c7d7466e25','2014-05-23 16:52:19',0,'Project overview show a column:  Team',58,30,30,13,'FINISHED','2014-05-26 11:49:29',NULL,'2014-05-26 15:51:39',NULL,NULL,'DEFAULT',0,NULL,'Show the team information on project overview page, and add a popover when click then show the team information on it.','',0,105),(106,'db12e4e01c9c43b28a5b4185b4d857c6','2014-05-23 16:54:01',0,'Project add ProductOwner field',58,30,30,13,'FINISHED','2014-05-26 11:49:23',NULL,'2014-05-26 14:31:07',NULL,NULL,'DEFAULT',0,NULL,'A project have one or more product owner, only show the refer projects when the product owner login the application go to project-overview page.','',0,106),(107,'2484d5b4ed39434798c3d0e0e24519c4','2014-05-28 13:41:55',0,'Sprint add Team field',58,60,60,13,'FINISHED','2014-05-28 13:42:08',58,'2014-05-28 17:03:05',NULL,NULL,'DEFAULT',0,NULL,'When create a new Sprint, a team will be assign to do the sprint.(Team from the projects)','',0,107),(108,'7929a3c573134664a49002ada3251cc8','2014-06-03 18:11:37',0,'Task overview show backlogs',61,60,30,17,'FINISHED','2014-06-05 13:06:18',58,'2014-06-05 13:22:08',NULL,NULL,'DEFAULT',0,15,'Show the sprint backlog on the task overview page, use popup, add a menu &quot;backlog&quot; at &quot;Action&quot; menu','',0,108),(109,'03938f65032345f4a45c5c7c23ab749c','2014-06-03 18:14:29',0,'Legend add count of type',61,60,60,17,'FINISHED','2014-06-04 14:26:53',61,'2014-06-04 16:49:24',NULL,NULL,'DEFAULT',0,NULL,'The Legend add a number that show the count of the type data.For example: Pending&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5, it is like User overview statistics area','',0,109),(110,'330630ca4f87470792eb82bd48bc1469','2014-06-03 18:19:31',0,'Task details show creator information',61,30,30,17,'FINISHED','2014-06-04 14:26:13',58,'2014-06-04 14:34:33',NULL,NULL,'DEFAULT',0,NULL,'FYI','',0,110),(111,'091dd6f724f042af95f9c5e84350d028','2014-06-03 18:20:58',0,'If a task already assigned to a member, then others member do not allow do it',61,60,60,17,'FINISHED','2014-06-05 10:46:21',58,'2014-06-05 12:12:22',NULL,NULL,'DEFAULT',0,NULL,'If a task already assigned to a member, then others member do not allow do it, in this condition, do not show &#39;Do it&#39; menu','',0,111),(112,'f11fc05a3eb845c0a4655ab9ff1768cc','2014-06-03 18:27:19',0,'Fix edit sprint un-bind team issue',61,30,30,17,'FINISHED','2014-06-04 16:49:51',58,'2014-06-04 17:05:19',NULL,NULL,'DEFAULT',1,NULL,'','It is ok , maybe have dirty data',0,112),(113,'c1f76043a4c4409bb717df2d0c2feb20','2014-06-03 18:39:04',0,'Backlog add documents fields',61,60,60,17,'FINISHED','2014-06-05 13:26:22',58,'2014-06-05 16:29:27',NULL,NULL,'DEFAULT',0,20,'Backlog add documents fields, allow upload multi documents','',0,113),(114,'2256e35af2524cac9ee08c5fb47825d3','2014-06-03 18:40:19',0,'Backlog form add/edit/delete documents',61,120,120,17,'FINISHED','2014-06-05 16:30:18',61,'2014-06-06 17:04:37',NULL,NULL,'DEFAULT',0,20,'If add:&nbsp; upload<br />\r\nIf Edit:&nbsp; Add new document or delete exist document','',0,114),(115,'d469e9fe9f1149eda787046db13e7eb3','2014-06-03 18:41:00',0,'Backlog overview show documents and download it',61,30,30,17,'FINISHED','2014-06-06 17:12:22',58,'2014-06-09 11:37:48',NULL,NULL,'DEFAULT',0,20,'Backlog overview show documents and download it','',0,115),(116,'3ca10ae85e9b4f1b8174b6804fe7da78','2014-06-04 10:16:51',0,'Only finish myself task, do not allow finish others tasks',58,30,30,17,'FINISHED','2014-06-04 17:19:32',61,'2014-06-04 17:38:56',NULL,NULL,'DEFAULT',0,NULL,'If the task executor is mine, then i can finish it, but others do not show finish it menu(Only limit member action, scrum master can do it)','',0,116),(117,'08eb23ce8f354b62b45fe3a76e0fd49e','2014-06-04 15:14:50',0,'Integrate properties',61,30,30,17,'FINISHED','2014-06-04 17:06:59',61,'2014-06-04 17:19:06',NULL,NULL,'DEFAULT',0,NULL,'Integrate properties(ad-db.properties, ad-mail.properties), remove old and add a full properties: andaily-developer.properties, all the configuration of the project add in the file, at the same time, change the pom.xml file for exclude the properties when building (war file)','',0,117),(118,'ddce94de78904f30a9f30ef24a5e88f0','2014-06-05 13:25:52',0,'Task number generate by project',61,60,60,17,'FINISHED','2014-06-05 13:26:11',61,'2014-06-05 15:07:27',NULL,NULL,'DEFAULT',0,18,'See backlog','',0,118),(119,'d317947a98a54639910113c0627bee6d','2014-06-05 13:36:10',0,'test',61,30,0,19,'CREATED',NULL,NULL,NULL,NULL,NULL,'DEFAULT',0,NULL,'test',NULL,0,119),(120,'eb0fbf54913549c58c5c76947ec9c4e5','2014-06-05 15:01:40',0,'Add file infrastructure ',61,60,60,17,'FINISHED','2014-06-05 15:09:14',61,'2014-06-05 15:48:46',NULL,NULL,'DEFAULT',0,NULL,'Add handle file operation utils class..','',0,123),(121,'c1467f9640e54cb2982b60ad3b538ad0','2014-06-05 15:05:42',0,'Task every tab add \'Only show my task\' checkbox',61,60,60,17,'FINISHED','2014-06-09 16:12:13',58,'2014-06-10 14:53:38',NULL,NULL,'DEFAULT',0,NULL,'Task every tab add &#39;Only show my task&#39; checkbox, it is convenient search filter','',0,124),(122,'39e473828ba849e7b4616587df992e0a','2014-06-05 15:06:55',0,'Task overview add search filter input area',61,60,60,17,'FINISHED','2014-06-09 11:39:57',61,'2014-06-09 16:10:10',NULL,NULL,'DEFAULT',0,NULL,'Task overview add search filter input area, support search by task number.','',0,129),(123,'8f6227cdda294174bc32c5fd11d8a234','2014-06-10 15:04:39',0,'Allow every project set a default sprint',61,60,60,17,'FINISHED','2014-06-12 14:29:40',61,'2014-06-12 17:49:35',NULL,NULL,'DEFAULT',0,16,'See backlog','',0,130),(124,'62c10ff5bf3c4a37ab02015c606db889','2014-06-10 15:08:38',0,'Sprint meeting overview add project code, Legend to Statistics',61,60,60,17,'FINISHED','2014-06-10 15:23:00',61,'2014-06-10 15:58:30',NULL,NULL,'DEFAULT',0,NULL,'Add project code in overview page sprint select element; the right area Legend change to Statistic, include count of every type meetings','',0,127),(125,'2f05edee61494f02b47c624dcd9f2834','2014-06-12 17:58:28',0,'Task add comment and show it(Only finished task)',61,90,0,17,'PENDING','2014-06-12 18:11:26',61,NULL,NULL,NULL,'DEFAULT',0,19,'See backlog, only finished task',NULL,0,130),(126,'6cad349ab0a242b29dcba2ffe91b1942','2014-06-12 18:08:36',0,'Pending sprint allow add or remove backlogs',61,120,0,17,'PENDING','2014-06-12 18:11:46',58,NULL,NULL,NULL,'DEFAULT',0,15,'A management page is required, in the page, allow add un-refered backlogs; remove not used backlogs yet until now.<br />\r\nAdd a submenu &quot;manage backlogs&quot; on the sprint menu',NULL,0,127);
/*!40000 ALTER TABLE `sprint_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sprint_task_move_record`
--

DROP TABLE IF EXISTS `sprint_task_move_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sprint_task_move_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `from_sprint_id` int(11) DEFAULT NULL,
  `to_sprint_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `from_sprint_id_index` (`from_sprint_id`),
  KEY `task_id_index` (`task_id`),
  KEY `to_sprint_id_index` (`to_sprint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sprint_task_move_record`
--

LOCK TABLES `sprint_task_move_record` WRITE;
/*!40000 ALTER TABLE `sprint_task_move_record` DISABLE KEYS */;
INSERT INTO `sprint_task_move_record` VALUES (20,'c6a9b7311a5b4ddeab6bd6550f79992c','2013-10-09 22:30:24',0,5,12,45),(21,'b813901fda3d4f49be3f9a6e3b632e56','2013-10-09 22:57:59',0,5,12,24),(22,'c89c0657d1904bdb95e269fa3ee22956','2013-10-09 22:58:08',0,5,12,56),(23,'74dc9524d8b94f0e8991f09a0e3c265d','2013-11-13 22:33:41',0,12,13,56),(24,'3dc5792f3a2449ef93730268db93ec83','2013-11-13 22:33:49',0,12,13,38),(25,'0b8c46df0ef9482085debac1ab6c9cff','2013-11-13 22:33:56',0,12,13,24),(26,'4b0c7b39b8354094a354ed818f56b001','2014-05-30 18:01:18',0,13,17,90),(27,'dede5f25c0494333a4718c05c25223c7','2014-05-30 18:01:33',0,13,17,56),(28,'f3b95ebfe3bf40eebdd2bbe3355f1b35','2014-05-30 18:01:40',0,13,17,38);
/*!40000 ALTER TABLE `sprint_task_move_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `name_` varchar(255) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `creator_id_index` (`creator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,'9d7b783795a8405981950c87519e79d7','2014-05-21 13:22:27',1,'911 team',50,'zzzzzzzzzzzzzzzzzzzz'),(3,'d50eef234d2847f4a1852b971982f66d','2014-05-21 13:30:22',0,'901',50,'This is our core team for <strong>VR development</strong> work.'),(4,'d847006dd2e34dc1b33cef6d06db47d6','2014-05-26 15:49:37',1,'T1',50,'Test'),(5,'7e7bb94d0b1e4fd0bcc23a6c915cbecb','2014-05-26 16:12:29',0,'TT1',50,'aadsfsf'),(6,'fd315da2db364addabdd5e78c6f6a0c3','2014-06-12 15:04:56',0,'IJO team',50,'The team from IJO corporation');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_project`
--

DROP TABLE IF EXISTS `team_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `project_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  KEY `guid_index` (`guid`),
  KEY `team_id_index` (`team_id`),
  KEY `project_id_index` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_project`
--

LOCK TABLES `team_project` WRITE;
/*!40000 ALTER TABLE `team_project` DISABLE KEYS */;
INSERT INTO `team_project` VALUES (9,'7800370b207d45e78bb822017781fe59','2014-05-26 16:12:29',0,2,5),(19,'d39df230c0c643de87da97b7a57bbc47','2014-06-12 14:39:17',0,1,3),(20,'be9f7746dcc3408b8500ddffca82a68a','2014-06-12 14:39:17',0,5,3),(21,'d362d32594bd469994d8f2f27af1693a','2014-06-12 15:04:56',0,5,6);
/*!40000 ALTER TABLE `team_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_`
--

DROP TABLE IF EXISTS `user_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `archived` tinyint(1) DEFAULT '0',
  `last_login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `city` varchar(255) DEFAULT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `cell_phone` varchar(255) DEFAULT NULL,
  `verify_code` varchar(255) DEFAULT NULL,
  `scrum_term` varchar(255) DEFAULT NULL,
  `type_` varchar(255) NOT NULL DEFAULT 'User',
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `cell_phone` (`cell_phone`),
  UNIQUE KEY `verify_code` (`verify_code`),
  KEY `user_guid_index` (`guid`),
  KEY `user_email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_`
--

LOCK TABLES `user_` WRITE;
/*!40000 ALTER TABLE `user_` DISABLE KEYS */;
INSERT INTO `user_` VALUES (1,'322os-9kkwew2-locde1-',NULL,0,'2013-04-13 05:33:38','monkeyking1987@126.com','7eedb15d71f49962208f4bd9200b7c12','Chengdu(成都)','mkk','13308231107',NULL,NULL,'User',NULL),(2,'user-uuid-2',NULL,1,'2012-04-27 09:29:10','monkeyk1987@gmail.com','05a671c66aefea124cc08b76ea6d30bb','Chengdu',NULL,'13344441107',NULL,NULL,'User',NULL),(3,'ce9362c4-2bfc-4154-83a8-68651669b167','2012-02-09 23:03:56',1,'2012-02-11 09:06:50','343344981@qq.com','edab525a39fa49a8638b7aad02200012','成都',NULL,'34444444444444',NULL,NULL,'User',NULL),(4,'627bbfc1-c606-4a34-8166-cd1fbe41e3de','2012-05-13 15:43:51',0,'2013-03-30 08:13:53','1589155482@qq.com','ce1403031ae5a0344a9835590ad5faf1','','pagelover','',NULL,NULL,'User',NULL),(6,'9fdf6cd70b1b40f9ad15ac02a57db90d','2013-03-12 23:43:48',0,'2013-03-30 07:37:43','249960083@qq.com','25d55ad283aa400af464c76d713c07ad','','',NULL,NULL,NULL,'User',NULL),(8,'452fd38f5f294755b26f1f7f632aa452','2013-03-26 17:05:04',0,'2013-03-30 07:37:43','softwindking@163.com','f71480207a9667a32f03415955906e48','','',NULL,NULL,NULL,'User',NULL),(9,'62494203a49e4d1ead9d1969d49032b4','2013-03-26 18:42:35',0,'2013-03-30 07:37:43','greenwishing@msn.cn','25d55ad283aa400af464c76d713c07ad','cd','wishing',NULL,NULL,NULL,'User',NULL),(10,'ccc554094c0c44c288e295e5031d3f86','2013-03-26 21:12:28',0,'2013-03-30 07:37:43','pagelover@qq.com','ce1403031ae5a0344a9835590ad5faf1','成都','pagelover','15196631289',NULL,NULL,'User',NULL),(29,'6d734f1bd85a41f98aa3ddbff6cae741','2013-04-13 05:48:34',0,'2013-04-13 05:52:30','574768274@qq.com','7f544c0832c57851d8621622cdc4daaf','','other me','123456',NULL,NULL,'User',NULL),(32,'e5f45d92937342febf91e4460ec0c214',NULL,0,'2013-04-22 08:58:09','13880306477@andaily.com','4428c6c474502e61151877825bb41961','成都','王文磊','13880306477',NULL,NULL,'User',NULL),(33,'990f291658fd49e1b09eaf9ff48e2dcb',NULL,0,'2013-04-22 08:58:10','mkk@andaily.com','4428c6c474502e61151877825bb41961','成都','李胜钊','13474007014',NULL,NULL,'User',NULL),(34,'d7f175c45c944ac3aeec6b47a18e00d2','2013-07-17 00:23:50',0,'2013-07-16 16:25:03','111@11.com','1bbd886460827015e5d605ed44252251','','111',NULL,NULL,NULL,'User',NULL),(35,'22c81ad7ae2d47f08066a101b310f8d3','2013-07-17 20:40:53',0,'2013-07-17 12:46:32','411277703@qq.com','1bbd886460827015e5d605ed44252251','xa','411277703','411277703',NULL,NULL,'User',NULL),(36,'c69950a821104b308ddd0bffaf9681be','2013-07-17 20:42:58',0,'2013-07-17 12:47:09','abc@126.com','1bbd886460827015e5d605ed44252251','','acb',NULL,NULL,NULL,'User',NULL),(37,'733f512b0ea54d7d9eb4d53d45ff2d31','2013-07-31 23:35:33',1,'2013-07-31 15:35:33','aswwdd@ad.com','1bbd886460827015e5d605ed44252251','','',NULL,'77fc39602ad041d59c9a828970f770d6',NULL,'User',NULL),(38,'d0ac35773f334c22b50747e6b476ed9d','2013-07-31 23:43:29',1,'2013-07-31 15:43:29','0987654@123.com','1bbd886460827015e5d605ed44252251','','',NULL,'323df93bd4894a818953f5083544e09f',NULL,'User',NULL),(39,'32d9f9cf0ca2498ea365b8a108d9cd95','2013-07-31 23:55:50',1,'2013-07-31 15:55:50','rrrrrrr@rr.com','1bbd886460827015e5d605ed44252251','','rRrRRR',NULL,'ca859c0a30d04f4a9fdd2df62a1f1645',NULL,'User',NULL),(40,'afea5451b7374c4895ae7d9635658f1b','2013-08-01 00:07:00',1,'2013-07-31 16:07:00','ewsadds@fdad.com','1bbd886460827015e5d605ed44252251','','',NULL,'bb8ec78bc7bf4c71a8d2f517a26544de',NULL,'User',NULL),(41,'1d75dd07fc244a2d971fed3df7402394','2013-08-01 23:24:08',0,'2013-08-01 15:26:29','9494@94.com','d234d5ac2a00b814828bb2ac3deba4bb','','9494',NULL,NULL,NULL,'User',NULL),(42,'edb824baf5574c85941a2af2a9b77dcc','2013-08-01 23:28:49',1,'2013-08-01 15:28:49','9999@99.com','1bbd886460827015e5d605ed44252251','','',NULL,'547445aaf8dd4130b0bb83fd1e2c5620',NULL,'User',NULL),(43,'228397d163e741e793754c438278db6e','2013-08-01 23:32:24',0,'2013-08-01 15:34:00','dddd@dd.com','c957fcad002e0517f5b5f8c0936feca4','','',NULL,NULL,NULL,'User',NULL),(50,'63a2974795ca4309925f209ab0af2688','2013-11-23 13:00:13',0,'2014-06-05 01:59:40','admin@andaily.com','dbd4adce1a9568c4b1413644f7363b66',NULL,'admin','43444',NULL,'SUPER_MAN','Developer',NULL),(52,'86d340150c75487b9166e3c3afc07112','2013-12-03 23:48:34',0,'2014-06-12 07:07:54','lukai@honyee.cc','dbd4adce1a9568c4b1413644f7363b66',NULL,'lukai','13308231108',NULL,'MEMBER','Developer',6),(53,'c6b43ff84c24494ba1011c6ffc1e57e0','2013-12-03 23:49:06',0,'2014-06-12 06:39:17','chengtao@honyee.cc','4852cce589b6595507e2f35764ccca84',NULL,'ct','134556676776',NULL,'MEMBER','Developer',3),(54,'5d475ffb838c4477920a3d7f8350398a','2013-12-03 23:50:59',0,'2014-06-05 07:15:48','chengtao1@honyee.cc','dbd4adce1a9568c4b1413644f7363b66',NULL,'p-owner','1566777777',NULL,'PRODUCT_OWNER','Developer',NULL),(55,'08100f2b9ee545739254ee42475c0af8','2013-12-03 23:51:18',0,'2014-06-12 06:34:04','kuangyawen@honyee.cc','7bc6bfb6789186843ecbfc70047c308d',NULL,'kuangyawen1111','2313244322',NULL,'MEMBER','Developer',NULL),(58,'79c3727cdddc406aa9d9ef6162a30e4e','2013-12-17 23:04:36',0,'2014-06-12 06:39:17','shengzhao@andaily.com','dbd4adce1a9568c4b1413644f7363b66',NULL,'shengzhao','1595123',NULL,'MEMBER','Developer',3),(59,'7f55cbfec79f40d4a09254f2f643912c','2013-12-17 23:07:19',0,'2014-05-26 08:12:29','shengzhao@honyee.cc','dbd4adce1a9568c4b1413644f7363b66',NULL,'master','1345566767763',NULL,'MASTER','Developer',5),(60,'dc4a8e16cd9440dba6bfbc808f1ddb8e','2013-12-17 23:08:02',0,'2014-05-26 08:12:29','sheng3zhao@wdcy.cc','f78e95a7c3176f2b40916fc683cd2f19',NULL,'asfsafd','15667777772',NULL,'MEMBER','Developer',5),(61,'6c8bfdb07545418084e7e1a37793ce52','2014-05-21 13:29:24',0,'2014-06-12 06:39:17','master1@andaily.com','dbd4adce1a9568c4b1413644f7363b66',NULL,'John',NULL,NULL,'MASTER','Developer',3),(62,'652f43563bc34c70a3f1d3c89a3ced2a','2014-05-26 14:29:25',0,'2014-05-26 10:01:34','powner@andaily.com','dbd4adce1a9568c4b1413644f7363b66',NULL,'Pick Owner',NULL,NULL,'PRODUCT_OWNER','Developer',NULL),(63,'275d1d691ed84a089b632bc1ad4eb02b','2014-06-12 15:04:23',0,'2014-06-12 07:04:56','ijo_master@andaily.com','dbd4adce1a9568c4b1413644f7363b66',NULL,'ijo_master','156677777724',NULL,'MASTER','Developer',6);
/*!40000 ALTER TABLE `user_` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-12 18:12:54
